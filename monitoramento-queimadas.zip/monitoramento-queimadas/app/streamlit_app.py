#!/usr/bin/env python
# -*- coding: utf-8 -*-

"""
Interface interativa em Streamlit para visualização de dados de focos de queimadas.

Este script carrega automaticamente todos os arquivos CSV em output/dados_limpos,
permite seleção de período, exibe filtros de UF e bioma, e mostra gráficos
interativos e mapa de dispersão dos focos.
"""

import os
import sys
import logging
import pandas as pd
import numpy as np
import streamlit as st
import plotly.express as px
from datetime import datetime, timedelta
from glob import glob

# Configuração de logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    handlers=[
        logging.FileHandler('output/logs/streamlit_app.log'),
        logging.StreamHandler(sys.stdout)
    ]
)
logger = logging.getLogger('monitoramento_queimadas.streamlit')

# Configuração da página Streamlit
st.set_page_config(
    page_title="Monitoramento de Queimadas",
    page_icon="🔥",
    layout="wide",
    initial_sidebar_state="expanded"
)

# Função para carregar dados
@st.cache_data(ttl=3600)  # Cache por 1 hora
def carregar_dados(diretorio='output/dados_limpos'):
    """
    Carrega todos os arquivos CSV do diretório especificado.
    
    Args:
        diretorio (str): Diretório contendo os arquivos CSV.
    
    Returns:
        pandas.DataFrame: DataFrame com todos os dados carregados.
    """
    try:
        # Listar arquivos CSV no diretório
        arquivos_csv = glob(os.path.join(diretorio, '*.csv'))
        
        if not arquivos_csv:
            st.error(f"Nenhum arquivo CSV encontrado em {diretorio}")
            return None
        
        logger.info(f"Carregando {len(arquivos_csv)} arquivos CSV")
        
        # Lista para armazenar DataFrames
        dfs = []
        
        # Carregar cada arquivo
        for arquivo in arquivos_csv:
            try:
                df = pd.read_csv(arquivo)
                
                # Verificar se a coluna de data existe
                if 'data' not in df.columns:
                    logger.warning(f"Coluna 'data' não encontrada no arquivo {arquivo}. Pulando.")
                    continue
                
                # Converter coluna de data para datetime
                df['data'] = pd.to_datetime(df['data'], errors='coerce')
                
                # Adicionar à lista
                dfs.append(df)
                
            except Exception as e:
                logger.error(f"Erro ao carregar arquivo {arquivo}: {str(e)}")
        
        if not dfs:
            st.error("Nenhum dado válido carregado")
            return None
        
        # Concatenar todos os DataFrames
        df_completo = pd.concat(dfs, ignore_index=True)
        
        logger.info(f"Total de registros carregados: {len(df_completo)}")
        return df_completo
    
    except Exception as e:
        logger.error(f"Erro ao carregar dados: {str(e)}")
        st.error(f"Erro ao carregar dados: {str(e)}")
        return None

# Função para filtrar dados por período
def filtrar_por_periodo(df, data_inicio, data_fim):
    """
    Filtra o DataFrame pelo período especificado.
    
    Args:
        df (pandas.DataFrame): DataFrame a ser filtrado.
        data_inicio (datetime): Data inicial do período.
        data_fim (datetime): Data final do período.
    
    Returns:
        pandas.DataFrame: DataFrame filtrado.
    """
    if df is None:
        return None
    
    try:
        # Verificar se a coluna de data existe
        if 'data' not in df.columns:
            st.error("Coluna 'data' não encontrada no DataFrame")
            return df
        
        # Filtrar por período
        df_filtrado = df[(df['data'] >= data_inicio) & (df['data'] <= data_fim)]
        
        logger.info(f"Dados filtrados por período: {len(df_filtrado)} registros")
        return df_filtrado
    
    except Exception as e:
        logger.error(f"Erro ao filtrar por período: {str(e)}")
        st.error(f"Erro ao filtrar por período: {str(e)}")
        return df

# Função para filtrar dados por UF
def filtrar_por_uf(df, ufs_selecionadas):
    """
    Filtra o DataFrame pelas UFs selecionadas.
    
    Args:
        df (pandas.DataFrame): DataFrame a ser filtrado.
        ufs_selecionadas (list): Lista de UFs selecionadas.
    
    Returns:
        pandas.DataFrame: DataFrame filtrado.
    """
    if df is None or not ufs_selecionadas:
        return df
    
    try:
        # Verificar se a coluna de UF existe
        if 'uf' not in df.columns:
            st.error("Coluna 'uf' não encontrada no DataFrame")
            return df
        
        # Filtrar por UF
        df_filtrado = df[df['uf'].isin(ufs_selecionadas)]
        
        logger.info(f"Dados filtrados por UF: {len(df_filtrado)} registros")
        return df_filtrado
    
    except Exception as e:
        logger.error(f"Erro ao filtrar por UF: {str(e)}")
        st.error(f"Erro ao filtrar por UF: {str(e)}")
        return df

# Função para filtrar dados por bioma
def filtrar_por_bioma(df, biomas_selecionados):
    """
    Filtra o DataFrame pelos biomas selecionados.
    
    Args:
        df (pandas.DataFrame): DataFrame a ser filtrado.
        biomas_selecionados (list): Lista de biomas selecionados.
    
    Returns:
        pandas.DataFrame: DataFrame filtrado.
    """
    if df is None or not biomas_selecionados:
        return df
    
    try:
        # Verificar se a coluna de bioma existe
        if 'bioma' not in df.columns:
            st.error("Coluna 'bioma' não encontrada no DataFrame")
            return df
        
        # Filtrar por bioma
        df_filtrado = df[df['bioma'].isin(biomas_selecionados)]
        
        logger.info(f"Dados filtrados por bioma: {len(df_filtrado)} registros")
        return df_filtrado
    
    except Exception as e:
        logger.error(f"Erro ao filtrar por bioma: {str(e)}")
        st.error(f"Erro ao filtrar por bioma: {str(e)}")
        return df

# Função para gerar série temporal
def gerar_serie_temporal(df, periodo='D'):
    """
    Gera série temporal de focos de queimadas.
    
    Args:
        df (pandas.DataFrame): DataFrame com os dados.
        periodo (str): Período de agregação ('D' para dia, 'W' para semana, 'M' para mês, 'Y' para ano).
    
    Returns:
        pandas.DataFrame: DataFrame com a série temporal.
    """
    if df is None or len(df) == 0:
        return None
    
    try:
        # Verificar se a coluna de data existe
        if 'data' not in df.columns:
            st.error("Coluna 'data' não encontrada no DataFrame")
            return None
        
        # Agrupar por período
        serie = df.groupby(pd.Grouper(key='data', freq=periodo)).size().reset_index(name='focos')
        
        logger.info(f"Série temporal gerada: {len(serie)} períodos")
        return serie
    
    except Exception as e:
        logger.error(f"Erro ao gerar série temporal: {str(e)}")
        st.error(f"Erro ao gerar série temporal: {str(e)}")
        return None

# Função para gerar contagem por UF
def contar_por_uf(df):
    """
    Conta focos por UF.
    
    Args:
        df (pandas.DataFrame): DataFrame com os dados.
    
    Returns:
        pandas.DataFrame: DataFrame com contagem por UF.
    """
    if df is None or len(df) == 0:
        return None
    
    try:
        # Verificar se a coluna de UF existe
        if 'uf' not in df.columns:
            st.error("Coluna 'uf' não encontrada no DataFrame")
            return None
        
        # Agrupar por UF
        contagem = df.groupby('uf').size().reset_index(name='focos')
        
        # Ordenar por número de focos (decrescente)
        contagem = contagem.sort_values('focos', ascending=False)
        
        logger.info(f"Contagem por UF gerada: {len(contagem)} UFs")
        return contagem
    
    except Exception as e:
        logger.error(f"Erro ao contar por UF: {str(e)}")
        st.error(f"Erro ao contar por UF: {str(e)}")
        return None

# Função para gerar contagem por bioma
def contar_por_bioma(df):
    """
    Conta focos por bioma.
    
    Args:
        df (pandas.DataFrame): DataFrame com os dados.
    
    Returns:
        pandas.DataFrame: DataFrame com contagem por bioma.
    """
    if df is None or len(df) == 0:
        return None
    
    try:
        # Verificar se a coluna de bioma existe
        if 'bioma' not in df.columns:
            st.error("Coluna 'bioma' não encontrada no DataFrame")
            return None
        
        # Agrupar por bioma
        contagem = df.groupby('bioma').size().reset_index(name='focos')
        
        # Ordenar por número de focos (decrescente)
        contagem = contagem.sort_values('focos', ascending=False)
        
        logger.info(f"Contagem por bioma gerada: {len(contagem)} biomas")
        return contagem
    
    except Exception as e:
        logger.error(f"Erro ao contar por bioma: {str(e)}")
        st.error(f"Erro ao contar por bioma: {str(e)}")
        return None

# Função principal
def main():
    """
    Função principal da interface Streamlit.
    """
    # Título da aplicação
    st.title("🔥 Monitoramento de Focos de Queimadas")
    
    # Carregar dados
    with st.spinner("Carregando dados..."):
        df = carregar_dados()
    
    if df is None or len(df) == 0:
        st.error("Não foi possível carregar os dados. Verifique se existem arquivos CSV em output/dados_limpos.")
        st.stop()
    
    # Sidebar para filtros
    st.sidebar.title("Filtros")
    
    # Filtro de período
    st.sidebar.subheader("Período")
    
    # Determinar datas mínima e máxima
    data_min = df['data'].min().date()
    data_max = df['data'].max().date()
    
    # Definir datas padrão (último mês)
    data_padrao_fim = data_max
    data_padrao_inicio = max(data_min, data_padrao_fim - timedelta(days=30))
    
    # Seletores de data
    data_inicio = st.sidebar.date_input("Data inicial", data_padrao_inicio, min_value=data_min, max_value=data_max)
    data_fim = st.sidebar.date_input("Data final", data_padrao_fim, min_value=data_min, max_value=data_max)
    
    # Converter para datetime
    data_inicio = pd.Timestamp(data_inicio)
    data_fim = pd.Timestamp(data_fim)
    
    # Filtro de UF
    st.sidebar.subheader("Unidades Federativas (UF)")
    
    # Obter lista de UFs
    if 'uf' in df.columns:
        ufs_disponiveis = sorted(df['uf'].unique())
        ufs_selecionadas = st.sidebar.multiselect("Selecione as UFs", ufs_disponiveis)
    else:
        ufs_selecionadas = []
        st.sidebar.warning("Coluna 'uf' não encontrada nos dados")
    
    # Filtro de bioma
    st.sidebar.subheader("Biomas")
    
    # Obter lista de biomas
    if 'bioma' in df.columns:
        biomas_disponiveis = sorted(df['bioma'].unique())
        biomas_selecionados = st.sidebar.multiselect("Selecione os biomas", biomas_disponiveis)
    else:
        biomas_selecionados = []
        st.sidebar.warning("Coluna 'bioma' não encontrada nos dados")
    
    # Aplicar filtros
    with st.spinner("Aplicando filtros..."):
        df_filtrado = filtrar_por_periodo(df, data_inicio, data_fim)
        
        if ufs_selecionadas:
            df_filtrado = filtrar_por_uf(df_filtrado, ufs_selecionadas)
        
        if biomas_selecionados:
            df_filtrado = filtrar_por_bioma(df_filtrado, biomas_selecionados)
    
    # Verificar se há dados após filtros
    if df_filtrado is None or len(df_filtrado) == 0:
        st.warning("Nenhum dado encontrado para os filtros selecionados.")
        st.stop()
    
    # Exibir informações gerais
    st.subheader("Informações Gerais")
    
    col1, col2, col3 = st.columns(3)
    
    with col1:
        st.metric("Total de Focos", f"{len(df_filtrado):,}")
    
    with col2:
        # Calcular média diária
        dias = (data_fim - data_inicio).days + 1
        media_diaria = len(df_filtrado) / dias if dias > 0 else 0
        st.metric("Média Diária", f"{media_diaria:.1f}")
    
    with col3:
        # Determinar tendência
        serie_temporal = gerar_serie_temporal(df_filtrado)
        if serie_temporal is not None and len(serie_temporal) > 1:
            primeiro_valor = serie_temporal['focos'].iloc[0]
            ultimo_valor = serie_temporal['focos'].iloc[-1]
            
            if ultimo_valor > primeiro_valor * 1.2:
                tendencia = "Crescente ↑"
            elif ultimo_valor < primeiro_valor * 0.8:
                tendencia = "Decrescente ↓"
            else:
                tendencia = "Estável →"
            
            st.metric("Tendência", tendencia)
    
    # Gráfico de linha (série temporal)
    st.subheader("Série Temporal de Focos de Queimadas")
    
    # Gerar série temporal
    serie_temporal = gerar_serie_temporal(df_filtrado)
    
    if serie_temporal is not None and not serie_temporal.empty:
        # Criar gráfico interativo com Plotly
        fig = px.line(
            serie_temporal,
            x='data',
            y='focos',
            title='Focos de Queimadas por Dia',
            labels={'data': 'Data', 'focos': 'Número de Focos'},
            line_shape='linear'
        )
        
        # Adicionar linha de média móvel
        serie_temporal['media_movel'] = serie_temporal['focos'].rolling(window=7, min_periods=1).mean()
        
        fig.add_scatter(
            x=serie_temporal['data'],
            y=serie_temporal['media_movel'],
            mode='lines',
            name='Média Móvel (7 dias)',
            line=dict(color='red', width=2)
        )
        
        # Configurar layout
        fig.update_layout(
            xaxis_title='Data',
            yaxis_title='Número de Focos',
            legend=dict(orientation='h', yanchor='bottom', y=1.02, xanchor='right', x=1),
            height=500
        )
        
        # Exibir gráfico
        st.plotly_chart(fig, use_container_width=True)
    else:
        st.warning("Não foi possível gerar a série temporal.")
    
    # Criar duas colunas para os gráficos de UF e bioma
    col1, col2 = st.columns(2)
    
    with col1:
        # Gráfico de barras (focos por UF)
        st.subheader("Focos por UF")
        
        # Contar focos por UF
        focos_por_uf = contar_por_uf(df_filtrado)
        
        if focos_por_uf is not None and not focos_por_uf.empty:
            # Limitar para as 10 UFs com mais focos
            top_ufs = focos_por_uf.head(10)
            
            # Criar gráfico interativo com Plotly
            fig = px.bar(
                top_ufs,
                x='uf',
                y='focos',
                title='Top 10 UFs com Mais Focos de Queimadas',
                labels={'uf': 'UF', 'focos': 'Número de Focos'},
                color='focos',
                color_continuous_scale='Reds'
            )
            
            # Configurar layout
            fig.update_layout(
                xaxis_title='UF',
                yaxis_title='Número de Focos',
                coloraxis_showscale=False,
                height=500
            )
            
            # Exibir gráfico
            st.plotly_chart(fig, use_container_width=True)
        else:
            st.warning("Não foi possível gerar o gráfico de focos por UF.")
    
    with col2:
        # Gráfico de pizza (focos por bioma)
        st.subheader("Focos por Bioma")
        
        # Contar focos por bioma
        focos_por_bioma = contar_por_bioma(df_filtrado)
        
        if focos_por_bioma is not None and not focos_por_bioma.empty:
            # Criar gráfico interativo com Plotly
            fig = px.pie(
                focos_por_bioma,
                names='bioma',
                values='focos',
                title='Distribuição de Focos de Queimadas por Bioma',
                color_discrete_sequence=px.colors.sequential.Reds
            )
            
            # Configurar layout
            fig.update_layout(
                legend=dict(orientation='h', yanchor='bottom', y=-0.3, xanchor='center', x=0.5),
                height=500
            )
            
            # Exibir gráfico
            st.plotly_chart(fig, use_container_width=True)
        else:
            st.warning("Não foi possível gerar o gráfico de focos por bioma.")
    
    # Tabela resumida
    st.subheader("Tabela Resumida")
    
    with st.expander("Ver tabelas detalhadas"):
        tab1, tab2 = st.tabs(["Por UF", "Por Bioma"])
        
        with tab1:
            if focos_por_uf is not None and not focos_por_uf.empty:
                # Adicionar coluna de percentual
                focos_por_uf['percentual'] = (focos_por_uf['focos'] / focos_por_uf['focos'].sum()) * 100
                
                # Exibir tabela formatada
                st.dataframe(
                    focos_por_uf.style.format({
                        'focos': '{:,}',
                        'percentual': '{:.2f}%'
                    }),
                    use_container_width=True
                )
            else:
                st.warning("Não há dados para exibir.")
        
        with tab2:
            if focos_por_bioma is not None and not focos_por_bioma.empty:
                # Adicionar coluna de percentual
                focos_por_bioma['percentual'] = (focos_por_bioma['focos'] / focos_por_bioma['focos'].sum()) * 100
                
                # Exibir tabela formatada
                st.dataframe(
                    focos_por_bioma.style.format({
                        'focos': '{:,}',
                        'percentual': '{:.2f}%'
                    }),
                    use_container_width=True
                )
            else:
                st.warning("Não há dados para exibir.")
    
    # Mapa de dispersão
    st.subheader("Mapa de Focos de Queimadas")
    
    # Verificar se existem coordenadas
    if 'latitude' in df_filtrado.columns and 'longitude' in df_filtrado.columns:
        # Remover registros com coordenadas nulas
        df_mapa = df_filtrado.dropna(subset=['latitude', 'longitude'])
        
        if len(df_mapa) > 0:
            # Limitar número de pontos para evitar sobrecarga
            max_pontos = 5000
            if len(df_mapa) > max_pontos:
                st.warning(f"Limitando a exibição para {max_pontos} pontos aleatórios (de um total de {len(df_mapa)}).")
                df_mapa = df_mapa.sample(max_pontos)
            
            # Criar mapa interativo com Plotly
            fig = px.scatter_mapbox(
                df_mapa,
                lat='latitude',
                lon='longitude',
                hover_name='uf' if 'uf' in df_mapa.columns else None,
                hover_data=['bioma'] if 'bioma' in df_mapa.columns else None,
                color='uf' if 'uf' in df_mapa.columns else None,
                size_max=10,
                zoom=3,
                height=600,
                title='Mapa de Focos de Queimadas'
            )
            
            fig.update_layout(mapbox_style='open-street-map')
            
            # Exibir mapa
            st.plotly_chart(fig, use_container_width=True)
        else:
            st.warning("Não há coordenadas válidas para exibir no mapa.")
    else:
        st.warning("Colunas de coordenadas (latitude e longitude) não encontradas nos dados.")
    
    # Rodapé
    st.markdown("---")
    st.markdown("**Sistema de Monitoramento de Queimadas** | Dados fornecidos pelo TerraBrasilis/INPE")

if __name__ == "__main__":
    main()
