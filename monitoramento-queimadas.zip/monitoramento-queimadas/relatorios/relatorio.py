#!/usr/bin/env python
# -*- coding: utf-8 -*-

"""
Módulo de geração de relatórios para focos de queimadas.

Este script monta relatório PDF ou HTML contendo sumário executivo, gráficos
(séries temporais, barras por UF, pizza por bioma), tabelas e possíveis alertas,
usando matplotlib, Plotly ou Jinja2 + WeasyPrint.
"""

import os
import sys
import logging
import argparse
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
from datetime import datetime, timedelta
from glob import glob
import jinja2
from weasyprint import HTML

# Configuração de logging
logger = logging.getLogger('monitoramento_queimadas.relatorios')

def carregar_dados_analise():
    """
    Carrega os dados de análise para geração do relatório.
    
    Returns:
        tuple: (serie_temporal, focos_por_uf, focos_por_bioma, alertas) com os dados carregados.
    """
    try:
        # Diretório de análises
        diretorio_analises = 'output/dados_limpos/analises'
        os.makedirs(diretorio_analises, exist_ok=True)
        
        # Carregar série temporal
        caminho_serie = os.path.join(diretorio_analises, 'serie_temporal_dia.csv')
        serie_temporal = None
        if os.path.exists(caminho_serie):
            serie_temporal = pd.read_csv(caminho_serie)
            serie_temporal['periodo'] = pd.to_datetime(serie_temporal['periodo'])
            logger.info(f"Série temporal carregada: {len(serie_temporal)} registros")
        else:
            logger.warning(f"Arquivo de série temporal não encontrado: {caminho_serie}")
        
        # Carregar focos por UF
        caminho_uf = os.path.join(diretorio_analises, 'focos_por_uf.csv')
        focos_por_uf = None
        if os.path.exists(caminho_uf):
            focos_por_uf = pd.read_csv(caminho_uf)
            logger.info(f"Focos por UF carregados: {len(focos_por_uf)} UFs")
        else:
            logger.warning(f"Arquivo de focos por UF não encontrado: {caminho_uf}")
        
        # Carregar focos por bioma
        caminho_bioma = os.path.join(diretorio_analises, 'focos_por_bioma.csv')
        focos_por_bioma = None
        if os.path.exists(caminho_bioma):
            focos_por_bioma = pd.read_csv(caminho_bioma)
            logger.info(f"Focos por bioma carregados: {len(focos_por_bioma)} biomas")
        else:
            logger.warning(f"Arquivo de focos por bioma não encontrado: {caminho_bioma}")
        
        # Carregar alertas
        alertas = []
        caminho_alertas = 'output/logs/alertas.log'
        if os.path.exists(caminho_alertas):
            with open(caminho_alertas, 'r', encoding='utf-8') as f:
                conteudo = f.read()
                # Extrair alertas do log (simplificado)
                if 'ALERTAS:' in conteudo:
                    alertas_raw = conteudo.split('ALERTAS:')[-1].split('FIM ALERTAS:')[0]
                    alertas = [linha.strip() for linha in alertas_raw.split('\n') if linha.strip()]
                    logger.info(f"Alertas carregados: {len(alertas)}")
        else:
            logger.warning(f"Arquivo de alertas não encontrado: {caminho_alertas}")
        
        return serie_temporal, focos_por_uf, focos_por_bioma, alertas
    
    except Exception as e:
        logger.error(f"Erro ao carregar dados de análise: {str(e)}")
        return None, None, None, []

def gerar_graficos_relatorio(serie_temporal, focos_por_uf, focos_por_bioma, diretorio_saida):
    """
    Gera gráficos para o relatório.
    
    Args:
        serie_temporal (pandas.DataFrame): Série temporal de focos.
        focos_por_uf (pandas.DataFrame): Focos por UF.
        focos_por_bioma (pandas.DataFrame): Focos por bioma.
        diretorio_saida (str): Diretório para salvar os gráficos.
    
    Returns:
        dict: Dicionário com caminhos para os gráficos gerados.
    """
    graficos = {}
    
    try:
        os.makedirs(diretorio_saida, exist_ok=True)
        
        # Gráfico de série temporal
        if serie_temporal is not None and not serie_temporal.empty:
            plt.figure(figsize=(10, 6))
            
            # Plotar série original
            plt.plot(serie_temporal['periodo'], serie_temporal['focos'], 'b-', label='Focos diários')
            
            # Plotar média móvel
            if 'media_movel' in serie_temporal.columns:
                plt.plot(serie_temporal['periodo'], serie_temporal['media_movel'], 'r-', label='Média móvel')
            
            # Configurar gráfico
            plt.title('Série Temporal de Focos de Queimadas')
            plt.xlabel('Data')
            plt.ylabel('Número de Focos')
            plt.grid(True, linestyle='--', alpha=0.7)
            plt.legend()
            
            # Ajustar layout
            plt.tight_layout()
            
            # Salvar
            caminho_grafico = os.path.join(diretorio_saida, 'serie_temporal.png')
            plt.savefig(caminho_grafico, dpi=300, bbox_inches='tight')
            plt.close()
            
            graficos['serie_temporal'] = caminho_grafico
            logger.info(f"Gráfico de série temporal salvo: {caminho_grafico}")
        
        # Gráfico de barras por UF
        if focos_por_uf is not None and not focos_por_uf.empty:
            plt.figure(figsize=(12, 8))
            
            # Limitar para as 10 UFs com mais focos
            df_plot = focos_por_uf.head(10).copy()
            
            # Plotar barras
            bars = plt.bar(df_plot['uf'], df_plot['focos'])
            
            # Adicionar rótulos
            for bar in bars:
                height = bar.get_height()
                plt.text(bar.get_x() + bar.get_width()/2., height + 5,
                        f'{height:,}', ha='center', va='bottom')
            
            # Configurar gráfico
            plt.title('Top 10 UFs com Mais Focos de Queimadas')
            plt.xlabel('UF')
            plt.ylabel('Número de Focos')
            plt.xticks(rotation=45)
            plt.grid(axis='y', linestyle='--', alpha=0.7)
            
            # Ajustar layout
            plt.tight_layout()
            
            # Salvar
            caminho_grafico = os.path.join(diretorio_saida, 'focos_por_uf.png')
            plt.savefig(caminho_grafico, dpi=300, bbox_inches='tight')
            plt.close()
            
            graficos['focos_por_uf'] = caminho_grafico
            logger.info(f"Gráfico de barras por UF salvo: {caminho_grafico}")
        
        # Gráfico de pizza por bioma
        if focos_por_bioma is not None and not focos_por_bioma.empty:
            plt.figure(figsize=(10, 10))
            
            # Plotar pizza
            plt.pie(
                focos_por_bioma['focos'],
                labels=focos_por_bioma['bioma'],
                autopct='%1.1f%%',
                startangle=90,
                shadow=True
            )
            
            # Configurar gráfico
            plt.title('Distribuição de Focos de Queimadas por Bioma')
            plt.axis('equal')  # Equal aspect ratio ensures that pie is drawn as a circle
            
            # Ajustar layout
            plt.tight_layout()
            
            # Salvar
            caminho_grafico = os.path.join(diretorio_saida, 'focos_por_bioma.png')
            plt.savefig(caminho_grafico, dpi=300, bbox_inches='tight')
            plt.close()
            
            graficos['focos_por_bioma'] = caminho_grafico
            logger.info(f"Gráfico de pizza por bioma salvo: {caminho_grafico}")
        
        return graficos
    
    except Exception as e:
        logger.error(f"Erro ao gerar gráficos para relatório: {str(e)}")
        return graficos

def gerar_relatorio_html(serie_temporal, focos_por_uf, focos_por_bioma, alertas, graficos, caminho_saida):
    """
    Gera relatório em formato HTML.
    
    Args:
        serie_temporal (pandas.DataFrame): Série temporal de focos.
        focos_por_uf (pandas.DataFrame): Focos por UF.
        focos_por_bioma (pandas.DataFrame): Focos por bioma.
        alertas (list): Lista de alertas.
        graficos (dict): Dicionário com caminhos para os gráficos.
        caminho_saida (str): Caminho para salvar o relatório.
    
    Returns:
        bool: True se o relatório foi gerado com sucesso, False caso contrário.
    """
    try:
        # Configurar ambiente Jinja2
        env = jinja2.Environment(
            loader=jinja2.FileSystemLoader('relatorios/templates'),
            autoescape=jinja2.select_autoescape(['html', 'xml'])
        )
        
        # Carregar template
        try:
            template = env.get_template('relatorio.html')
        except jinja2.exceptions.TemplateNotFound:
            # Criar template padrão se não existir
            os.makedirs('relatorios/templates', exist_ok=True)
            with open('relatorios/templates/relatorio.html', 'w', encoding='utf-8') as f:
                f.write("""
                <!DOCTYPE html>
                <html>
                <head>
                    <meta charset="UTF-8">
                    <meta name="viewport" content="width=device-width, initial-scale=1.0">
                    <title>Relatório de Focos de Queimadas</title>
                    <style>
                        body { font-family: Arial, sans-serif; margin: 0; padding: 20px; color: #333; }
                        h1 { color: #d9534f; border-bottom: 2px solid #d9534f; padding-bottom: 10px; }
                        h2 { color: #5bc0de; margin-top: 30px; }
                        table { border-collapse: collapse; width: 100%; margin: 20px 0; }
                        th, td { border: 1px solid #ddd; padding: 8px; text-align: left; }
                        th { background-color: #f2f2f2; }
                        .alerta { color: #d9534f; font-weight: bold; }
                        .grafico { max-width: 100%; height: auto; margin: 20px 0; }
                        .sumario { background-color: #f9f9f9; padding: 15px; border-left: 4px solid #5bc0de; }
                        .footer { margin-top: 50px; border-top: 1px solid #ddd; padding-top: 10px; font-size: 0.8em; color: #777; }
                    </style>
                </head>
                <body>
                    <h1>Relatório de Focos de Queimadas</h1>
                    <p>Data de geração: {{ data_geracao }}</p>
                    
                    <div class="sumario">
                        <h2>Sumário Executivo</h2>
                        <p>Este relatório apresenta uma análise dos focos de queimadas detectados no período de {{ periodo_inicio }} a {{ periodo_fim }}.</p>
                        <p>Total de focos no período: <strong>{{ total_focos }}</strong></p>
                        {% if tendencia %}
                        <p>Tendência: <strong>{{ tendencia }}</strong></p>
                        {% endif %}
                    </div>
                    
                    {% if alertas %}
                    <h2>Alertas</h2>
                    <ul class="alerta">
                        {% for alerta in alertas %}
                        <li>{{ alerta }}</li>
                        {% endfor %}
                    </ul>
                    {% endif %}
                    
                    <h2>Série Temporal</h2>
                    {% if graficos.serie_temporal %}
                    <img src="{{ graficos.serie_temporal }}" alt="Série Temporal" class="grafico">
                    {% else %}
                    <p>Gráfico de série temporal não disponível.</p>
                    {% endif %}
                    
                    <h2>Distribuição por UF</h2>
                    {% if graficos.focos_por_uf %}
                    <img src="{{ graficos.focos_por_uf }}" alt="Focos por UF" class="grafico">
                    {% else %}
                    <p>Gráfico de distribuição por UF não disponível.</p>
                    {% endif %}
                    
                    {% if focos_por_uf %}
                    <table>
                        <tr>
                            <th>UF</th>
                            <th>Focos</th>
                            <th>Percentual</th>
                        </tr>
                        {% for _, row in focos_por_uf.iterrows() %}
                        <tr>
                            <td>{{ row.uf }}</td>
                            <td>{{ row.focos }}</td>
                            <td>{{ "%.2f"|format(row.percentual) }}%</td>
                        </tr>
                        {% endfor %}
                    </table>
                    {% endif %}
                    
                    <h2>Distribuição por Bioma</h2>
                    {% if graficos.focos_por_bioma %}
                    <img src="{{ graficos.focos_por_bioma }}" alt="Focos por Bioma" class="grafico">
                    {% else %}
                    <p>Gráfico de distribuição por bioma não disponível.</p>
                    {% endif %}
                    
                    {% if focos_por_bioma %}
                    <table>
                        <tr>
                            <th>Bioma</th>
                            <th>Focos</th>
                            <th>Percentual</th>
                        </tr>
                        {% for _, row in focos_por_bioma.iterrows() %}
                        <tr>
                            <td>{{ row.bioma }}</td>
                            <td>{{ row.focos }}</td>
                            <td>{{ "%.2f"|format(row.percentual) }}%</td>
                        </tr>
                        {% endfor %}
                    </table>
                    {% endif %}
                    
                    <div class="footer">
                        <p>Relatório gerado automaticamente pelo Sistema de Monitoramento de Queimadas.</p>
                    </div>
                </body>
                </html>
                """)
            template = env.get_template('relatorio.html')
        
        # Preparar dados para o template
        data_geracao = datetime.now().strftime('%d/%m/%Y %H:%M:%S')
        
        periodo_inicio = "N/A"
        periodo_fim = "N/A"
        total_focos = 0
        tendencia = "N/A"
        
        if serie_temporal is not None and not serie_temporal.empty:
            periodo_inicio = serie_temporal['periodo'].min().strftime('%d/%m/%Y')
            periodo_fim = serie_temporal['periodo'].max().strftime('%d/%m/%Y')
            total_focos = serie_temporal['focos'].sum()
            
            # Determinar tendência
            if len(serie_temporal) > 1:
                ultimos_dias = serie_temporal.iloc[-7:] if len(serie_temporal) >= 7 else serie_temporal
                primeiro_valor = ultimos_dias['focos'].iloc[0]
                ultimo_valor = ultimos_dias['focos'].iloc[-1]
                
                if ultimo_valor > primeiro_valor * 1.2:
                    tendencia = "Crescente ↑"
                elif ultimo_valor < primeiro_valor * 0.8:
                    tendencia = "Decrescente ↓"
                else:
                    tendencia = "Estável →"
        
        # Renderizar template
        html_content = template.render(
            data_geracao=data_geracao,
            periodo_inicio=periodo_inicio,
            periodo_fim=periodo_fim,
            total_focos=total_focos,
            tendencia=tendencia,
            alertas=alertas,
            graficos=graficos,
            focos_por_uf=focos_por_uf.to_dict('records') if focos_por_uf is not None else None,
            focos_por_bioma=focos_por_bioma.to_dict('records') if focos_por_bioma is not None else None
        )
        
        # Salvar HTML
        with open(caminho_saida, 'w', encoding='utf-8') as f:
            f.write(html_content)
        
        logger.info(f"Relatório HTML gerado: {caminho_saida}")
        return True
    
    except Exception as e:
        logger.error(f"Erro ao gerar relatório HTML: {str(e)}")
        return False

def gerar_relatorio_pdf(caminho_html, caminho_pdf):
    """
    Converte relatório HTML para PDF.
    
    Args:
        caminho_html (str): Caminho para o relatório HTML.
        caminho_pdf (str): Caminho para salvar o relatório PDF.
    
    Returns:
        bool: True se o relatório foi gerado com sucesso, False caso contrário.
    """
    try:
        # Converter HTML para PDF
        HTML(caminho_html).write_pdf(caminho_pdf)
        
        logger.info(f"Relatório PDF gerado: {caminho_pdf}")
        return True
    
    except Exception as e:
        logger.error(f"Erro ao gerar relatório PDF: {str(e)}")
        return False

def main(formato='pdf', periodo='mes', output=None):
    """
    Função principal do módulo de relatórios.
    
    Args:
        formato (str, optional): Formato do relatório ('pdf', 'html').
        periodo (str, optional): Período do relatório ('dia', 'semana', 'mes', 'ano').
        output (str, optional): Caminho de saída do relatório.
    
    Returns:
        str: Caminho para o relatório gerado, ou None se ocorrer um erro.
    """
    logger.info(f"Iniciando geração de relatório no formato {formato}")
    
    try:
        # Carregar dados de análise
        serie_temporal, focos_por_uf, focos_por_bioma, alertas = carregar_dados_analise()
        
        # Definir diretório e nome do relatório
        data_atual = datetime.now().strftime('%Y%m%d')
        
        if output:
            caminho_saida = output
            diretorio_saida = os.path.dirname(output)
        else:
            diretorio_saida = 'output/relatorios'
            os.makedirs(diretorio_saida, exist_ok=True)
            caminho_saida = os.path.join(diretorio_saida, f'relatorio_{periodo}_{data_atual}')
        
        # Gerar gráficos
        graficos = gerar_graficos_relatorio(serie_temporal, focos_por_uf, focos_por_bioma, diretorio_saida)
        
        # Gerar relatório HTML
        caminho_html = f"{caminho_saida}.html"
        sucesso_html = gerar_relatorio_html(serie_temporal, focos_por_uf, focos_por_bioma, alertas, graficos, caminho_html)
        
        if not sucesso_html:
            logger.error("Falha ao gerar relatório HTML")
            return None
        
        # Se o formato for PDF, converter HTML para PDF
        if formato.lower() == 'pdf':
            caminho_pdf = f"{caminho_saida}.pdf"
            sucesso_pdf = gerar_relatorio_pdf(caminho_html, caminho_pdf)
            
            if not sucesso_pdf:
                logger.error("Falha ao gerar relatório PDF")
                return caminho_html  # Retorna o HTML como fallback
            
            logger.info(f"Relatório gerado com sucesso: {caminho_pdf}")
            return caminho_pdf
        else:
            logger.info(f"Relatório gerado com sucesso: {caminho_html}")
            return caminho_html
    
    except Exception as e:
        logger.error(f"Erro durante a geração do relatório: {str(e)}", exc_info=True)
        return None

if __name__ == "__main__":
    # Configurar parser de argumentos
    parser = argparse.ArgumentParser(description='Geração de relatórios de focos de queimadas')
    parser.add_argument('--formato', type=str, default='pdf', choices=['pdf', 'html'], help='Formato do relatório')
    parser.add_argument('--periodo', type=str, default='mes', choices=['dia', 'semana', 'mes', 'ano'], help='Período do relatório')
    parser.add_argument('--output', type=str, help='Caminho de saída do relatório')
    args = parser.parse_args()
    
    # Configurar logging
    logging.basicConfig(
        level=logging.INFO,
        format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
        handlers=[
            logging.FileHandler('output/logs/relatorio.log'),
            logging.StreamHandler(sys.stdout)
        ]
    )
    
    # Executar geração de relatório
    main(args.formato, args.periodo, args.output)
